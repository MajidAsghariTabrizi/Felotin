<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Amado - Furniture Ecommerce Template | Home</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="css/style.css">

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

    <!-- Animate.css -->
    <link rel="stylesheet" href="Blog/css/animate.css">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="Blog/css/icomoon.css">
    <!-- Bootstrap  -->
    <link rel="stylesheet" href="Blog/css/bootstrap.css">

    <!-- Magnific Popup -->
    <link rel="stylesheet" href="Blog/css/magnific-popup.css">

    <!-- Flexslider  -->
    <link rel="stylesheet" href="Blog/css/flexslider.css">

    <!-- Owl Carousel -->
    <link rel="stylesheet" href="Blog/css/owl.carousel.min.css">
    <link rel="stylesheet" href="Blog/css/owl.theme.default.min.css">

    <!-- Flaticons  -->
    <link rel="stylesheet" href="Blog/fonts/flaticon/font/flaticon.css">

    <!-- Theme style  -->
    <link rel="stylesheet" href="Blog/css/style.css">

    <!-- Modernizr JS -->
    <script src="Blog/js/modernizr-2.6.2.min.js"></script>

    <script src="Blog/js/respond.min.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body  dir="rtl" lang="fa">

    <!-- Navigation -->
