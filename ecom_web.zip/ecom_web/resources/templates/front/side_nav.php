
        <header class="header-area clearfix"  style="float: right">
            <!-- Close Icon -->
            <div class="nav-close">
                <i class="fa fa-close" aria-hidden="true"></i>
            </div>
            <!-- Logo -->
            <div class="logo">
                <a href="index.php"><img src="img/core-img/logo.png" alt=""></a>
            </div>
            <!-- Amado Nav -->
            <nav class="amado-nav">
                <ul>

                    <li class="active"><a href="blog.php">نشر نو</a></li>
                    <?php
                    if(!isset($_SESSION['username']) && empty($_SESSION['username']))

                    {

                        echo '                    <li><a href="login.php">ورود به حساب کاربری</a></li>';
                    }

                    else
                    {
                        echo '                    <li><a href="logout.php">خروج از سیستم</a></li>';

                        echo '                    <li><a href="#">'.display_login_message();'</a></li>';



                    }


                    ?>
                    <li><a href="checkout.html">تکمیل اطلاعات</a></li>
                </ul>
            </nav>
            <!-- Button Group -->
            <div class="amado-btn-group mt-30 mb-100">
                <a href="#" class="btn amado-btn mb-15">%تخفیف بگیر%</a>
                <a href="#" class="btn amado-btn active">تازه های این هفته</a>
            </div>


               <div class="cart-fav-search mb-100">
                   <a href="checkout.php?user=<?php $_SESSION ['username']?>" class="cart-nav"><img src="img/core-img/cart.png" alt="">سبد خرید  <span>(<?php Product_count();?>)</span></a>

                <a href="#" class="search-nav"><img src="img/core-img/search.png" alt=""> جست و جو</a>
            </div>
            <!-- Social Button -->
            <div class="social-info d-flex justify-content-between">
                <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            </div>
        </header>

