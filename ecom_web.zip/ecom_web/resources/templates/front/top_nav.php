            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                <button style="background-color:#FBB704;border-bottom-color: #0a2b1d"  class="btn btn-primary">  <a class="navbar-brand" href="index.php">Home</a></button>
                    <?php
                    if(!isset($_SESSION['username']) && empty($_SESSION['username']))

                    {

                        echo '<button style="background-color:#FBB704;border-bottom-color: #0a2b1d"  class="btn btn-primary"><a class="navbar-brand"  href="login.php">Log In</a></button>';
                    }

                    else
                    {
                        echo  '<button style="background-color:#FBB704;border-bottom-color: #0a2b1d"  class="btn btn-primary"><a class="navbar-brand"  href="logout.php">Log Out</a></button>';


                        echo '<div style="position: relative" ">'.display_login_message();' </div>' ;

                    }


                    ?>

                </a>

            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <!-- /.navbar-collapse -->
        <!-- /.container -->